"""
camera.py
---------
Thin wrapper around OpenCV's VideoCapture for a USB webcam.

Responsibilities (Phase 7 scope only):
    - Open/close the camera device.
    - Read frames reliably, with clear errors if the camera drops out.
    - Discard warm-up frames so auto-exposure has settled before the
      caller acts on anything.
    - Report the ACTUAL resolution/FPS obtained (which may differ from
      what was requested - webcams often silently pick the nearest
      supported mode).

Does NOT do any image processing, detection, or classification -
that's detection.py (Phase 8) and classification.py (Phase 9/10),
which will import this module and call read_frame() in a loop.
"""

import logging
import time
from typing import Optional

import cv2
import numpy as np

import configuration

logger = logging.getLogger("camera")


class CameraError(Exception):
    """Raised when the camera cannot be opened or a frame cannot be read."""


def list_camera_indexes(max_index_to_check: int = 5) -> list:
    """
    Probes camera indexes 0..max_index_to_check-1 and returns the list
    of indexes that successfully opened and returned a frame. Useful
    for figuring out the correct CAMERA_INDEX without guessing.

    NOTE: this briefly opens/closes each device it checks - if a
    camera is already in use elsewhere, it will be reported as
    unavailable even if it physically exists.
    """
    available = []
    for index in range(max_index_to_check):
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            ok, _ = cap.read()
            if ok:
                available.append(index)
        cap.release()
    return available


class Camera:
    """
    Manages a single OpenCV VideoCapture device.

    Typical usage:
        with Camera() as cam:
            frame = cam.read_frame()
            ...

    or without the context manager:
        cam = Camera()
        cam.open()
        frame = cam.read_frame()
        cam.close()
    """

    def __init__(
        self,
        index: int = configuration.CAMERA_INDEX,
        width: int = configuration.CAMERA_WIDTH,
        height: int = configuration.CAMERA_HEIGHT,
        fps: int = configuration.CAMERA_FPS,
    ):
        self.index = index
        self.requested_width = width
        self.requested_height = height
        self.requested_fps = fps
        self._cap: Optional[cv2.VideoCapture] = None

        # Populated after open() - the resolution/FPS actually granted
        # by the camera, which may differ from what was requested.
        self.actual_width: Optional[int] = None
        self.actual_height: Optional[int] = None
        self.actual_fps: Optional[float] = None

    def open(self):
        """
        Opens the camera device and applies requested settings.
        Raises CameraError if the device cannot be opened, or if it
        opens but never produces a valid frame during warm-up.
        """
        logger.info("Opening camera index %d...", self.index)
        self._cap = cv2.VideoCapture(self.index)

        if not self._cap.isOpened():
            self._cap = None
            raise CameraError(
                f"Could not open camera index {self.index}. "
                f"Try list_camera_indexes() to find a valid index."
            )

        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.requested_width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.requested_height)
        self._cap.set(cv2.CAP_PROP_FPS, self.requested_fps)

        self.actual_width = int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.actual_height = int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.actual_fps = self._cap.get(cv2.CAP_PROP_FPS)

        if (self.actual_width, self.actual_height) != (self.requested_width, self.requested_height):
            logger.warning(
                "Requested %dx%d but camera provided %dx%d - using actual resolution.",
                self.requested_width, self.requested_height,
                self.actual_width, self.actual_height,
            )
        else:
            logger.info("Camera resolution: %dx%d @ %.1f fps", self.actual_width, self.actual_height, self.actual_fps)

        self._warm_up()

    def _warm_up(self):
        """Reads and discards a few frames so auto-exposure/white-balance settle."""
        discarded = 0
        for _ in range(configuration.CAMERA_WARMUP_FRAMES):
            ok, _ = self._cap.read()
            if ok:
                discarded += 1
            else:
                # Not fatal during warm-up - some webcams need a moment
                # before the very first reads succeed.
                time.sleep(0.05)

        if discarded == 0:
            raise CameraError(
                f"Camera index {self.index} opened but never returned a valid frame "
                f"during warm-up. Check the camera is not in use by another program."
            )

        logger.debug("Warm-up complete (%d/%d frames read).", discarded, configuration.CAMERA_WARMUP_FRAMES)

    def read_frame(self) -> np.ndarray:
        """
        Reads and returns a single frame as a BGR numpy array (OpenCV's
        default color order). Raises CameraError if the read fails -
        callers (detection.py's loop, Phase 8) should catch this and
        decide whether to retry or abort, rather than silently
        continuing with a stale/garbage frame.
        """
        if self._cap is None:
            raise CameraError("Camera is not open - call open() first.")

        ok, frame = self._cap.read()
        if not ok or frame is None:
            raise CameraError(f"Failed to read frame from camera index {self.index}.")

        return frame

    def close(self):
        """Releases the camera device. Safe to call multiple times."""
        if self._cap is not None:
            self._cap.release()
            logger.info("Camera released.")
        self._cap = None

    def is_open(self) -> bool:
        return self._cap is not None and self._cap.isOpened()

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False  # don't suppress exceptions
