"""
configuration.py
-----------------
Central place for ALL configurable constants used by the Python side
of the project. Change values here, not inside logic modules.

Serial/communication constants (Phase 6) and camera constants
(Phase 7) are defined so far. Detection, classification, and decision
constants will be added here in later phases (8-11) rather than
scattered across files.
"""

# =====================================================
# SERIAL CONNECTION
# =====================================================
# TODO: CONFIGURE AFTER HARDWARE SELECTION — the exact port depends on
# your OS and USB setup. Common examples:
#   Windows:      "COM3", "COM4", ...
#   Linux:        "/dev/ttyUSB0", "/dev/ttyACM0"
#   macOS:        "/dev/cu.usbserial-XXXX", "/dev/cu.SLAB_USBtoUART"
# Use list_serial_ports() in communication.py to discover the right one.
SERIAL_PORT = "COM3"

# Must match SERIAL_BAUD_RATE in esp32/configuration.h exactly.
SERIAL_BAUD_RATE = 115200

# How long to wait (seconds) for the ESP32's immediate response
# (OK / BUSY / ERROR / STATUS,...) after sending any command.
COMMAND_RESPONSE_TIMEOUT_SECONDS = 2.0

# How long to wait (seconds) for an async DONE,<label> after a
# critical action (ARM,* / GRIP,* / SORT,*) returns OK. Should be
# comfortably longer than ARM_MOVE_TIMEOUT_MS / GRIPPER_MOVE_TIMEOUT_MS
# on the ESP32 side (both currently a few seconds).
DONE_TIMEOUT_SECONDS = 6.0

# How long to wait (seconds) for the "READY" line after opening the
# serial port. The ESP32 resets when a serial connection opens, so
# this needs to cover boot + module init time.
CONNECT_TIMEOUT_SECONDS = 5.0

# =====================================================
# CAMERA (Phase 7)
# =====================================================
# TODO: CONFIGURE AFTER HARDWARE SELECTION — CAMERA_INDEX depends on
# how many video devices your OS sees. 0 is usually the first/only
# USB webcam, but if you have a built-in laptop webcam too, the
# external one may be index 1. Use list_camera_indexes() in camera.py
# to check what's available.
CAMERA_INDEX = 0

# Requested capture resolution. The camera may not support this exact
# resolution and will silently fall back to its nearest supported
# mode - camera.py logs the ACTUAL resolution obtained after opening,
# always check that log line rather than assuming these values apply.
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
CAMERA_FPS = 30

# How many warm-up frames to read and discard right after opening the
# camera. Many USB webcams return a few dark/garbage frames while
# auto-exposure settles - skipping them avoids acting on bad frames.
CAMERA_WARMUP_FRAMES = 5

# =====================================================
# LOGGING
# =====================================================
LOG_LEVEL = "INFO"  # one of "DEBUG", "INFO", "WARNING", "ERROR"

