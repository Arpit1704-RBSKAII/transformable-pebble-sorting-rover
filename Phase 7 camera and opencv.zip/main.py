"""
main.py — PHASE 7 TEST VERSION
--------------------------------
Entry point for manual phase-by-phase testing. Each phase's test is
its own function so earlier phases stay runnable as the project grows
(useful for re-checking hardware after wiring changes, etc.).

Usage:
    python main.py serial      # Phase 6 smoke test (ESP32 link only)
    python main.py camera      # Phase 7 smoke test (camera preview + snapshots)

Later phases will add more subcommands here rather than replacing
earlier ones - by Phase 14 (full integration) this becomes the single
real run loop, but until then each phase stays independently testable.
"""

import logging
import sys

import cv2

import configuration
from communication import (
    RoverSerialLink,
    SerialCommandError,
    SerialTimeoutError,
    list_serial_ports,
)
from camera import Camera, CameraError, list_camera_indexes


def setup_logging():
    logging.basicConfig(
        level=getattr(logging, configuration.LOG_LEVEL),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


def run_serial_test():
    """Phase 6 smoke test: connect to ESP32, exercise ARM/GRIP, disconnect."""
    logger = logging.getLogger("main.serial")

    logger.info("Available serial ports:")
    for device, description in list_serial_ports():
        logger.info("  %s - %s", device, description)

    link = RoverSerialLink()

    try:
        link.connect()
    except SerialTimeoutError as exc:
        logger.error("Could not connect: %s", exc)
        logger.error(
            "Check configuration.SERIAL_PORT (%s) matches your ESP32's port, "
            "and that Phase 5 firmware is uploaded.",
            configuration.SERIAL_PORT,
        )
        sys.exit(1)

    try:
        status = link.get_status()
        logger.info("Initial status: %s", status)

        logger.info("Sending ARM,HOME...")
        response = link.send_command("ARM,HOME")
        logger.info("Immediate response: %s", response)
        if response == "OK":
            done = link.wait_for_done("ARM_HOME")
            logger.info("Completed: %s", done)
        elif response == "BUSY":
            logger.warning("ESP32 was busy - skipping wait.")
        else:
            logger.error("Unexpected response to ARM,HOME: %s", response)

        logger.info("Sending GRIP,OPEN...")
        response = link.send_command("GRIP,OPEN")
        logger.info("Immediate response: %s", response)
        if response == "OK":
            done = link.wait_for_done("GRIP_OPEN")
            logger.info("Completed: %s", done)

        logger.info("Sending GRIP,CLOSE...")
        response = link.send_command("GRIP,CLOSE")
        logger.info("Immediate response: %s", response)
        if response == "OK":
            done = link.wait_for_done("GRIP_CLOSE")
            logger.info("Completed: %s", done)

        status = link.get_status()
        logger.info("Final status: %s", status)

        logger.info("Phase 6 smoke test completed successfully.")

    except SerialCommandError as exc:
        logger.error("ESP32 reported an error: %s", exc.reason)
    except SerialTimeoutError as exc:
        logger.error("Timed out waiting for a response: %s", exc)
    finally:
        link.disconnect()


def run_camera_test():
    """
    Phase 7 smoke test: opens the camera, shows a live preview window,
    and lets you save snapshots for later detection/calibration work.

    Controls (with the preview window focused):
        's' - save the current frame to python/tests/snapshots/
        'q' or ESC - quit
    """
    logger = logging.getLogger("main.camera")

    logger.info("Available camera indexes: %s", list_camera_indexes())

    import os
    snapshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests", "snapshots")
    os.makedirs(snapshot_dir, exist_ok=True)

    try:
        with Camera() as cam:
            logger.info(
                "Camera open at %dx%d. Press 's' to save a snapshot, 'q' to quit.",
                cam.actual_width, cam.actual_height,
            )
            snapshot_count = 0

            while True:
                try:
                    frame = cam.read_frame()
                except CameraError as exc:
                    logger.error("Frame read failed: %s", exc)
                    break

                cv2.imshow("Phase 7 - Camera Preview", frame)
                key = cv2.waitKey(1) & 0xFF

                if key == ord('q') or key == 27:  # 'q' or ESC
                    logger.info("Quit requested.")
                    break
                elif key == ord('s'):
                    snapshot_count += 1
                    path = os.path.join(snapshot_dir, f"snapshot_{snapshot_count:03d}.png")
                    cv2.imwrite(path, frame)
                    logger.info("Saved snapshot: %s", path)

    except CameraError as exc:
        logger.error("Camera error: %s", exc)
        logger.error(
            "Check configuration.CAMERA_INDEX (%d) is correct and the camera "
            "isn't in use by another program.",
            configuration.CAMERA_INDEX,
        )
        sys.exit(1)
    finally:
        cv2.destroyAllWindows()

    logger.info("Phase 7 camera test completed.")


def main():
    setup_logging()

    if len(sys.argv) < 2:
        print("Usage: python main.py [serial|camera]")
        sys.exit(1)

    mode = sys.argv[1]
    if mode == "serial":
        run_serial_test()
    elif mode == "camera":
        run_camera_test()
    else:
        print(f"Unknown mode: {mode}")
        print("Usage: python main.py [serial|camera]")
        sys.exit(1)


if __name__ == "__main__":
    main()
